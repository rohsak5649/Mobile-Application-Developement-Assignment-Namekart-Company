//
//  ToDoListAppApp.swift
//  ToDoListApp
//
//  Created by Rohan Sakhare on 20/08/24.
//

import SwiftUI

@main
struct ToDoListAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
